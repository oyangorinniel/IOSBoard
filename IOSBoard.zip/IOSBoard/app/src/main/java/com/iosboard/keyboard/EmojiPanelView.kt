package com.iosboard.keyboard

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.LinearLayout
import android.widget.TextView

/** Emoji picker with category tabs, a recents tab, an ABC button and a delete button. */
class EmojiPanelView(context: Context) : LinearLayout(context) {

    interface Listener {
        fun onEmoji(emoji: String)
        fun onBackToLetters()
        fun onDelete()
    }

    var listener: Listener? = null

    private var theme = KeyboardTheme.LIGHT
    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = (v * density).toInt()

    private val grid = GridView(context)
    private val tabs = LinearLayout(context)
    private var current = 0
    private var items: List<String> = emptyList()

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val tv = (convertView as? TextView) ?: TextView(context).apply {
                gravity = Gravity.CENTER
                textSize = 26f
                layoutParams = AbsListViewParams(dp(44f))
            }
            tv.text = items[position]
            return tv
        }
    }

    private fun AbsListViewParams(h: Int) =
        android.widget.AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)

    init {
        orientation = VERTICAL
        grid.numColumns = 8
        grid.adapter = adapter
        grid.isVerticalScrollBarEnabled = false
        grid.selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
        grid.setOnItemClickListener { _, _, position, _ ->
            val e = items[position]
            Prefs.addRecent(context, e)
            listener?.onEmoji(e)
        }
        addView(grid, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        tabs.orientation = HORIZONTAL
        tabs.gravity = Gravity.CENTER_VERTICAL
        addView(tabs, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46f)))

        applyPrefs()
    }

    fun applyPrefs() {
        theme = KeyboardTheme.resolve(context)
        setBackgroundColor(theme.background)
        buildTabs()
        select(current)
    }

    /** Refresh the Recents list every time the panel is opened. */
    fun onShown() {
        select(current)
    }

    private fun tabView(text: String, size: Float, weight: Float, bold: Boolean = false, click: () -> Unit): TextView {
        return TextView(context).apply {
            this.text = text
            textSize = size
            gravity = Gravity.CENTER
            setTextColor(theme.text)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setOnClickListener { click() }
            layoutParams = LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
        }
    }

    private fun buildTabs() {
        tabs.removeAllViews()
        tabs.addView(tabView("ABC", 15f, 1.3f, true) { listener?.onBackToLetters() })
        tabs.addView(tabView("🕒", 18f, 1f) { select(0) })
        EmojiData.categories.forEachIndexed { i, c ->
            tabs.addView(tabView(c.icon, 18f, 1f) { select(i + 1) })
        }
        tabs.addView(tabView("⌫", 20f, 1.3f) { listener?.onDelete() })
    }

    private fun select(index: Int) {
        current = index
        items = if (index == 0) {
            val r = Prefs.recents(context)
            if (r.isEmpty()) EmojiData.categories[0].emojis.take(24) else r
        } else {
            EmojiData.categories[index - 1].emojis
        }
        adapter.notifyDataSetChanged()
        grid.setSelection(0)

        // highlight the active tab (index 0 and last child are ABC / delete)
        for (i in 1 until tabs.childCount - 1) {
            val v = tabs.getChildAt(i)
            if (i - 1 == index) {
                val bg = GradientDrawable().apply {
                    cornerRadius = dp(8f).toFloat()
                    setColor(theme.specialFill)
                }
                v.background = bg
            } else {
                v.background = null
            }
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val h = dp(46f * 5.95f * Prefs.heightPercent(context) / 100f + 62f)
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY))
    }
}

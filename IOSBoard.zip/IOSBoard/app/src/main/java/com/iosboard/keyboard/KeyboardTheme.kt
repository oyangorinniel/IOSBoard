package com.iosboard.keyboard

import android.content.Context
import android.content.res.Configuration

/** Colors that imitate the iOS keyboard in light and dark mode. */
class KeyboardTheme(
    val background: Int,
    val keyFill: Int,
    val specialFill: Int,
    val keyShadow: Int,
    val text: Int,
    val accent: Int,
    val accentText: Int,
    val isDark: Boolean
) {
    companion object {
        val LIGHT = KeyboardTheme(
            background = 0xFFD1D3D9.toInt(),
            keyFill = 0xFFFFFFFF.toInt(),
            specialFill = 0xFFADB3BC.toInt(),
            keyShadow = 0xFF898A8D.toInt(),
            text = 0xFF000000.toInt(),
            accent = 0xFF007AFF.toInt(),
            accentText = 0xFFFFFFFF.toInt(),
            isDark = false
        )

        val DARK = KeyboardTheme(
            background = 0xFF2B2B2D.toInt(),
            keyFill = 0xFF6A6A6D.toInt(),
            specialFill = 0xFF454548.toInt(),
            keyShadow = 0xFF1A1A1C.toInt(),
            text = 0xFFFFFFFF.toInt(),
            accent = 0xFF0A84FF.toInt(),
            accentText = 0xFFFFFFFF.toInt(),
            isDark = true
        )

        fun resolve(context: Context): KeyboardTheme {
            return when (Prefs.theme(context)) {
                1 -> LIGHT
                2 -> DARK
                else -> {
                    val night = context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
                    if (night == Configuration.UI_MODE_NIGHT_YES) DARK else LIGHT
                }
            }
        }
    }
}

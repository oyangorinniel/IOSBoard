package com.iosboard.keyboard

/**
 * Emoji lists, space separated. These are drawn with the phone's own emoji font
 * (Noto Color Emoji on most Android phones), so no copyrighted emoji artwork is bundled.
 */
object EmojiData {

    class Category(val icon: String, val emojis: List<String>)

    private fun list(s: String): List<String> = s.trim().split(Regex("\\s+"))

    val categories: List<Category> = listOf(
        Category(
            "😀",
            list(
                "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🤩 🥳 " +
                    "😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 " +
                    "🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 " +
                    "😈 👿 👹 👺 🤡 💩 👻 💀 👽 👾 🤖 🎃 " +
                    "👋 🤚 ✋ 🖖 👌 🤞 🤟 🤘 🤙 👈 👉 👆 👇 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 💪 👀 👅 👄 💋"
            )
        ),
        Category(
            "🐻",
            list(
                "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 " +
                    "🐝 🐛 🦋 🐌 🐞 🐜 🐢 🐍 🦎 🐙 🦑 🦐 🦀 🐡 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐅 🐆 🦓 🦍 🐘 🦏 🐪 🐫 🦒 " +
                    "🐃 🐂 🐄 🐎 🐖 🐏 🐑 🐐 🦌 🐕 🐩 🐈 🐓 🦃 🐇 🐁 🐀 🌵 🎄 🌲 🌳 🌴 🌱 🌿 🍀 🍁 🍂 🍃 " +
                    "🌺 🌻 🌹 🌷 🌼 🌸 💐 🍄 🌎 🌙 ⭐ 🌟 ✨ ⚡ 🔥 🌈 💧 🌊"
            )
        ),
        Category(
            "🍔",
            list(
                "🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍈 🍒 🍑 🍍 🥥 🥝 🍅 🍆 🥑 🥦 🥒 🌽 🥕 🥔 🍠 🥐 🍞 🥖 🧀 🥚 🍳 " +
                    "🥞 🥓 🥩 🍗 🍖 🌭 🍔 🍟 🍕 🥪 🌮 🌯 🥗 🍝 🍜 🍲 🍛 🍣 🍱 🍤 🍙 🍚 🍘 🍥 🍢 🍡 🍧 🍨 🍦 " +
                    "🥧 🍰 🎂 🍮 🍭 🍬 🍫 🍿 🍩 🍪 🥛 ☕ 🍵 🍶 🍺 🍻 🥂 🍷 🥃 🍸 🍹 🍾 🥤 🥢 🍴 🥄"
            )
        ),
        Category(
            "⚽",
            list(
                "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏉 🎱 🏓 🏸 🥅 🏒 ⛳ 🏹 🎣 🥊 🥋 🎿 🏂 🎯 🎮 🎲 🎰 🧩 🎭 🎨 🎬 🎤 🎧 🎼 " +
                    "🎹 🥁 🎷 🎺 🎸 🎻 🏆 🥇 🥈 🥉 🏅 🎫"
            )
        ),
        Category(
            "🚗",
            list(
                "🚗 🚕 🚙 🚌 🚎 🚓 🚑 🚒 🚐 🚚 🚛 🚜 🛵 🚲 🛴 🚨 🚔 🚍 🚘 🚖 🚡 🚠 🚟 🚃 🚋 🚞 🚝 🚄 🚅 🚈 " +
                    "🚂 🚆 🚇 🚊 🚉 🛫 🛬 🚀 🛸 🚁 🛶 ⛵ 🚤 🚢 ⚓ 🚧 ⛽ 🚏 🚦 🚥 🗿 🗽 🗼 🏰 🏯 🎡 🎢 🎠 ⛲ " +
                    "🌋 🗻 ⛺ 🏠 🏡 🏢 🏬 🏣 🏤 🏥 🏦 🏨 🏪 🏫 🏩 💒 ⛪ 🕌 🕍"
            )
        ),
        Category(
            "💡",
            list(
                "⌚ 📱 📲 💻 💽 💾 💿 📀 📼 📷 📸 📹 🎥 📞 📟 📠 📺 📻 🧭 ⏰ ⏳ ⌛ 📡 🔋 🔌 💡 🔦 💸 💵 💴 " +
                    "💶 💷 💰 💳 💎 🔧 🔨 🔩 🔫 💣 🔪 🔮 📿 💈 🔭 🔬 💊 💉 🚽 🚿 🛁 🔑 🚪 🛒 🎁 🎈 🎏 🎀 " +
                    "🎊 🎉 📩 📦 📪 📫 📮 📜 📃 📄 📑 📊 📈 📉 📆 📅 📇 📋 📁 📂 📰 📓 📔 📒 📕 📗 📘 📙 " +
                    "📚 📖 🔖 🔗 📎 📐 📏 📌 📍 📝 🔍 🔎 🔏 🔐 🔒 🔓"
            )
        ),
        Category(
            "❤️",
            list(
                "❤️ 🧡 💛 💚 💙 💜 🖤 💔 💕 💞 💓 💗 💖 💘 💝 💟 💯 💢 💥 💫 💦 💨 💤 ✅ ❌ ❎ ❓ ❔ ❕ ❗ " +
                    "⭕ 🚫 🔱 🔰 ➕ ➖ ➗ ➰ ➿ 💲 🆗 🆒 🆕 🆓 🆙 🆘 🔴 🔵 ⚫ ⚪ 🔶 🔷 🔸 🔹 🔺 🔻 💠 🔘 🔲 🔳 " +
                    "⏩ ⏪ ⏫ ⏬ 🔼 🔽 🔀 🔁 🔂 🔄 🔃 🎵 🎶"
            )
        ),
        Category(
            "🇵🇭",
            list(
                "🇵🇭 🇺🇸 🇬🇧 🇯🇵 🇰🇷 🇨🇳 🇨🇦 🇦🇺 🇸🇬 🇩🇪 🇫🇷 🇪🇸 🇮🇹 🇧🇷 🇮🇳 🇲🇽 🇸🇦 🇦🇪 🇳🇿 🇹🇭 🇻🇳 " +
                    "🇮🇩 🇲🇾 🇭🇰 🇹🇼 🇷🇺 🇹🇷 🇳🇱 🇸🇪 🇨🇭 🇮🇪 🇵🇹 🇦🇷 🇿🇦 🇪🇬 🇳🇬 🇰🇼 🇶🇦 🇮🇱 🇬🇷"
            )
        )
    )
}

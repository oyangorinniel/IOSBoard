package com.iosboard.keyboard

/** A small list of very common typos, fixed when you press space. */
object Autocorrect {
    private val map: Map<String, String> = mapOf(
        "i" to "I",
        "im" to "I'm",
        "ive" to "I've",
        "dont" to "don't",
        "cant" to "can't",
        "wont" to "won't",
        "didnt" to "didn't",
        "doesnt" to "doesn't",
        "isnt" to "isn't",
        "wasnt" to "wasn't",
        "werent" to "weren't",
        "arent" to "aren't",
        "havent" to "haven't",
        "hasnt" to "hasn't",
        "hadnt" to "hadn't",
        "couldnt" to "couldn't",
        "wouldnt" to "wouldn't",
        "shouldnt" to "shouldn't",
        "youre" to "you're",
        "youve" to "you've",
        "youll" to "you'll",
        "theyre" to "they're",
        "thats" to "that's",
        "whats" to "what's",
        "teh" to "the",
        "taht" to "that",
        "adn" to "and",
        "wich" to "which",
        "thier" to "their",
        "becuase" to "because",
        "recieve" to "receive",
        "wierd" to "weird",
        "definately" to "definitely",
        "seperate" to "separate",
        "alot" to "a lot",
        "untill" to "until",
        "tommorow" to "tomorrow",
        "tomorow" to "tomorrow",
        "occured" to "occurred",
        "goverment" to "government"
    )

    fun fix(word: String): String? = map[word.lowercase()]
}

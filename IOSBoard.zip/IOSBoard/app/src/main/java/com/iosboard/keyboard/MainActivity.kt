package com.iosboard.keyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Setup screen: enable the keyboard, select it, open settings, and try it out. */
class MainActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }

        col.addView(text("iOS Board", 30f, true))
        col.addView(text("An iOS-style keyboard that works in Messenger, Viber and every other app.", 15f, false))
        col.addView(space(20))

        col.addView(text("Step 1", 13f, true))
        col.addView(button("Enable keyboard") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        col.addView(text("Turn on \"iOS Board Keyboard\" in the list.", 13f, false))
        col.addView(space(16))

        col.addView(text("Step 2", 13f, true))
        col.addView(button("Choose keyboard") {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        col.addView(text("Pick \"iOS Board Keyboard\" as the active keyboard.", 13f, false))
        col.addView(space(16))

        col.addView(text("Step 3", 13f, true))
        col.addView(button("Keyboard settings") {
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        col.addView(text("Theme, size, vibration, popup and more.", 13f, false))
        col.addView(space(16))

        col.addView(text("Try it here", 13f, true))
        col.addView(EditText(this).apply {
            hint = "Type something..."
            minLines = 3
            gravity = Gravity.TOP
        })

        val scroll = ScrollView(this)
        scroll.addView(col)
        setContentView(scroll)
    }

    private fun text(s: String, size: Float, bold: Boolean) = TextView(this).apply {
        text = s
        textSize = size
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun space(h: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(h))
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
        setTextColor(Color.WHITE)
        setBackgroundColor(0xFF007AFF.toInt())
    }
}

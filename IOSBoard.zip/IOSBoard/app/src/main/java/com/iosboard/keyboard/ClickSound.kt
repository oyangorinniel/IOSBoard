package com.iosboard.keyboard

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/** A tiny synthesized key click. Plays even when Android's "touch sounds" setting is off. */
object ClickSound {
    private var track: AudioTrack? = null

    private fun create(): AudioTrack? {
        return try {
            val rate = 22050
            val n = (rate * 0.035).toInt()
            val pcm = ShortArray(n) { i ->
                val t = i / rate.toDouble()
                (sin(2 * PI * 1600 * t) * exp(-t * 140.0) * 0.7 * 32767).toInt().toShort()
            }
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(n * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(pcm, 0, n)
            t
        } catch (e: Exception) {
            null
        }
    }

    fun play() {
        try {
            val t = track ?: create()?.also { track = it } ?: return
            t.stop()
            t.reloadStaticData()
            t.play()
        } catch (e: Exception) {
            track = null
        }
    }
}

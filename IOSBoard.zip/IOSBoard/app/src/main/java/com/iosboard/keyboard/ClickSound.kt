package com.iosboard.keyboard

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Three synthesized key sounds that follow the iOS pattern:
 * a crisp tick for letters, a lower tock for delete, and a duller thud for
 * shift / 123 / space / return. They play even when Android's touch sounds are off.
 */
object ClickSound {
    const val LETTER = 0
    const val DELETE = 1
    const val SPECIAL = 2

    private val tracks = arrayOfNulls<AudioTrack>(3)

    private fun synth(kind: Int): ShortArray {
        val rate = 22050
        val seconds = if (kind == LETTER) 0.03 else 0.04
        val n = (rate * seconds).toInt()
        val rnd = java.util.Random(7L + kind)

        var f1 = 2400.0
        var f2 = 3600.0
        var decay = 220.0
        var noiseAmt = 0.5
        when (kind) {
            DELETE -> {
                f1 = 1100.0
                f2 = 1700.0
                decay = 160.0
                noiseAmt = 0.3
            }
            SPECIAL -> {
                f1 = 780.0
                f2 = 1250.0
                decay = 150.0
                noiseAmt = 0.25
            }
        }
        val a = f1
        val b = f2
        val d = decay
        val na = noiseAmt

        return ShortArray(n) { i ->
            val t = i / rate.toDouble()
            val noise = (rnd.nextDouble() - 0.5) * 2.0
            val v = (0.6 * sin(2 * PI * a * t) + 0.35 * sin(2 * PI * b * t) + na * noise) * exp(-t * d) * 0.6
            (v.coerceIn(-1.0, 1.0) * 32767).toInt().toShort()
        }
    }

    private fun create(kind: Int): AudioTrack? {
        return try {
            val pcm = synth(kind)
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(22050)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(pcm.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(pcm, 0, pcm.size)
            t
        } catch (e: Exception) {
            null
        }
    }

    fun play(kind: Int) {
        try {
            val t = tracks[kind] ?: create(kind)?.also { tracks[kind] = it } ?: return
            t.stop()
            t.reloadStaticData()
            t.play()
        } catch (e: Exception) {
            tracks[kind] = null
        }
    }
}

package com.iosboard.keyboard

import android.content.Context
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.view.inputmethod.InputMethodManager
import android.view.inputmethod.InputMethodSubtype
import android.widget.Toast
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.FrameLayout

class IosKeyboardService : InputMethodService() {

    private lateinit var root: FrameLayout
    private lateinit var keyboard: IosKeyboardView
    private lateinit var emoji: EmojiPanelView

    private var lastSpaceTime = 0L
    private var imeAction = EditorInfo.IME_ACTION_NONE
    private var multiLine = false

    override fun onCreateInputView(): View {
        keyboard = IosKeyboardView(this)
        emoji = EmojiPanelView(this)
        emoji.visibility = View.GONE

        keyboard.listener = object : IosKeyboardView.Listener {
            override fun onText(text: String) {
                currentInputConnection?.commitText(text, 1)
                lastSpaceTime = 0L
                updateSuggestions()
            }

            override fun onSuggestion(word: String) {
                val ic = currentInputConnection ?: return
                val cur = currentWord()
                if (cur.isNotEmpty()) ic.deleteSurroundingText(cur.length, 0)
                ic.commitText("$word ", 1)
                if (word.length >= 2 && !isPasswordField()) Prefs.learnWord(this@IosKeyboardService, word.lowercase())
                lastSpaceTime = 0L
                updateAutoCap()
                updateSuggestions()
            }

            override fun onDelete() {
                deleteOne()
                updateAutoCap()
            }

            override fun onSpace() {
                val ic = currentInputConnection ?: return
                learnCurrentWord()
                val now = System.currentTimeMillis()
                if (Prefs.doubleSpace(this@IosKeyboardService) && now - lastSpaceTime < 400) {
                    val before = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
                    if (before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
                        ic.deleteSurroundingText(1, 0)
                        ic.commitText(". ", 1)
                        lastSpaceTime = 0L
                        updateAutoCap()
                        updateSuggestions()
                        return
                    }
                }
                ic.commitText(" ", 1)
                lastSpaceTime = now
                updateAutoCap()
                updateSuggestions()
            }

            override fun onEnter() {
                val ic = currentInputConnection ?: return
                learnCurrentWord()
                if (multiLine || imeAction == EditorInfo.IME_ACTION_NONE ||
                    imeAction == EditorInfo.IME_ACTION_UNSPECIFIED
                ) {
                    ic.commitText("\n", 1)
                } else {
                    ic.performEditorAction(imeAction)
                }
                updateAutoCap()
                updateSuggestions()
            }

            override fun onEmoji() {
                showEmoji(true)
            }

            override fun onVoice() {
                startVoiceTyping()
            }

            override fun onShiftChanged(state: Int) {
                // nothing extra; the view already redrew itself
            }
        }

        emoji.listener = object : EmojiPanelView.Listener {
            override fun onEmoji(emoji: String) {
                currentInputConnection?.commitText(emoji, 1)
            }

            override fun onBackToLetters() {
                showEmoji(false)
            }

            override fun onDelete() {
                deleteOne()
            }
        }

        root = FrameLayout(this)
        root.addView(keyboard)
        root.addView(emoji)
        return root
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!::keyboard.isInitialized) return

        keyboard.applyPrefs()
        emoji.applyPrefs()
        showEmoji(false)
        keyboard.showLetters()

        multiLine = (info.inputType and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0
        imeAction = info.imeOptions and EditorInfo.IME_MASK_ACTION

        if ((info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) {
            multiLine = true
        }

        val label: String
        var action = true
        when (imeAction) {
            EditorInfo.IME_ACTION_GO -> label = "go"
            EditorInfo.IME_ACTION_SEARCH -> label = "search"
            EditorInfo.IME_ACTION_SEND -> label = "send"
            EditorInfo.IME_ACTION_NEXT -> label = "next"
            EditorInfo.IME_ACTION_DONE -> label = "done"
            else -> {
                label = "return"
                action = false
            }
        }
        if (multiLine) {
            keyboard.setEnterKey("return", false)
        } else {
            keyboard.setEnterKey(label, action)
        }

        updateAutoCap()
        updateSuggestions()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    private fun showEmoji(show: Boolean) {
        if (!::emoji.isInitialized) return
        if (show) {
            emoji.onShown()
            emoji.visibility = View.VISIBLE
            keyboard.visibility = View.INVISIBLE
        } else {
            emoji.visibility = View.GONE
            keyboard.visibility = View.VISIBLE
        }
    }

    private fun deleteOne() {
        val ic: InputConnection = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (selected != null && selected.isNotEmpty()) {
            ic.commitText("", 1)
        } else {
            // delete a whole emoji / surrogate pair correctly
            ic.deleteSurroundingTextInCodePoints(1, 0)
        }
        updateSuggestions()
    }

    /** Hands over to the phone's voice typing keyboard (for example Google voice typing). */
    @Suppress("DEPRECATION")
    private fun startVoiceTyping() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        try {
            var bestId: String? = null
            var bestSub: InputMethodSubtype? = null
            for (info in imm.enabledInputMethodList) {
                if (info.packageName == packageName) continue
                for (st in imm.getEnabledInputMethodSubtypeList(info, true)) {
                    if (st.mode.equals("voice", ignoreCase = true)) {
                        if (bestId == null || info.id.contains("google", ignoreCase = true)) {
                            bestId = info.id
                            bestSub = st
                        }
                    }
                }
            }
            if (bestId != null && bestSub != null) {
                if (Build.VERSION.SDK_INT >= 28) {
                    switchInputMethod(bestId, bestSub)
                } else {
                    val token = window?.window?.attributes?.token
                    if (token != null) {
                        imm.setInputMethodAndSubtype(token, bestId, bestSub)
                    }
                }
                return
            }
        } catch (e: Exception) {
        }
        Toast.makeText(
            this,
            "No voice typing keyboard found. Enable Google voice typing in your phone's keyboard settings.",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun isPasswordField(): Boolean {
        val t = currentInputEditorInfo?.inputType ?: return false
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        return if (cls == InputType.TYPE_CLASS_TEXT) {
            v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                v == InputType.TYPE_TEXT_VARIATION_URI
        } else {
            cls != InputType.TYPE_CLASS_TEXT
        }
    }

    /** The letters right before the cursor, i.e. the word being typed. */
    private fun currentWord(): String {
        val ic = currentInputConnection ?: return ""
        val before = ic.getTextBeforeCursor(40, 0)?.toString() ?: return ""
        var i = before.length
        while (i > 0 && (before[i - 1].isLetter() || before[i - 1] == '\'')) i--
        return before.substring(i)
    }

    private fun learnCurrentWord() {
        if (isPasswordField()) return
        val w = currentWord()
        if (w.length >= 2) Prefs.learnWord(this, w.lowercase())
    }

    private fun updateSuggestions() {
        if (!::keyboard.isInitialized) return
        if (!Prefs.suggest(this) || isPasswordField()) {
            keyboard.setSuggestions(emptyList())
            return
        }
        val w = currentWord()
        if (w.isEmpty()) {
            keyboard.setSuggestions(listOf("I", "The", "I'm"))
            return
        }
        var comps = Dictionary.suggest(this, w, 2)
        if (w.length > 1 && w.all { it.isUpperCase() || it == '\'' }) {
            comps = comps.map { it.uppercase() }
        } else if (w[0].isUpperCase()) {
            comps = comps.map { it.replaceFirstChar { c -> c.uppercase() } }
        }
        keyboard.setSuggestions(listOf(w) + comps)
    }

    /** Sets shift automatically at sentence starts when the app asks for capitals. */
    private fun updateAutoCap() {
        if (!::keyboard.isInitialized) return
        if (keyboard.shiftState == IosKeyboardView.SHIFT_LOCK) return
        if (!Prefs.autoCap(this)) {
            if (keyboard.shiftState == IosKeyboardView.SHIFT_ON) keyboard.setShift(IosKeyboardView.SHIFT_OFF)
            return
        }
        val info = currentInputEditorInfo ?: return
        if (info.inputType == InputType.TYPE_NULL) return
        val ic = currentInputConnection ?: return
        val caps = ic.getCursorCapsMode(info.inputType)
        keyboard.setShift(if (caps != 0) IosKeyboardView.SHIFT_ON else IosKeyboardView.SHIFT_OFF)
    }
}

package com.iosboard.keyboard

import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.FrameLayout

class IosKeyboardService : InputMethodService() {

    private lateinit var root: FrameLayout
    private lateinit var keyboard: IosKeyboardView
    private lateinit var emoji: EmojiPanelView

    private var lastSpaceTime = 0L
    private var imeAction = EditorInfo.IME_ACTION_NONE
    private var multiLine = false

    override fun onCreateInputView(): View {
        keyboard = IosKeyboardView(this)
        emoji = EmojiPanelView(this)
        emoji.visibility = View.GONE

        keyboard.listener = object : IosKeyboardView.Listener {
            override fun onText(text: String) {
                currentInputConnection?.commitText(text, 1)
                lastSpaceTime = 0L
            }

            override fun onDelete() {
                deleteOne()
                updateAutoCap()
            }

            override fun onSpace() {
                val ic = currentInputConnection ?: return
                val now = System.currentTimeMillis()
                if (Prefs.doubleSpace(this@IosKeyboardService) && now - lastSpaceTime < 400) {
                    val before = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
                    if (before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
                        ic.deleteSurroundingText(1, 0)
                        ic.commitText(". ", 1)
                        lastSpaceTime = 0L
                        updateAutoCap()
                        return
                    }
                }
                ic.commitText(" ", 1)
                lastSpaceTime = now
                updateAutoCap()
            }

            override fun onEnter() {
                val ic = currentInputConnection ?: return
                if (multiLine || imeAction == EditorInfo.IME_ACTION_NONE ||
                    imeAction == EditorInfo.IME_ACTION_UNSPECIFIED
                ) {
                    ic.commitText("\n", 1)
                } else {
                    ic.performEditorAction(imeAction)
                }
                updateAutoCap()
            }

            override fun onEmoji() {
                showEmoji(true)
            }

            override fun onShiftChanged(state: Int) {
                // nothing extra; the view already redrew itself
            }
        }

        emoji.listener = object : EmojiPanelView.Listener {
            override fun onEmoji(emoji: String) {
                currentInputConnection?.commitText(emoji, 1)
            }

            override fun onBackToLetters() {
                showEmoji(false)
            }

            override fun onDelete() {
                deleteOne()
            }
        }

        root = FrameLayout(this)
        root.addView(keyboard)
        root.addView(emoji)
        return root
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!::keyboard.isInitialized) return

        keyboard.applyPrefs()
        emoji.applyPrefs()
        showEmoji(false)
        keyboard.showLetters()

        multiLine = (info.inputType and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0
        imeAction = info.imeOptions and EditorInfo.IME_MASK_ACTION

        if ((info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) {
            multiLine = true
        }

        val label: String
        var action = true
        when (imeAction) {
            EditorInfo.IME_ACTION_GO -> label = "go"
            EditorInfo.IME_ACTION_SEARCH -> label = "search"
            EditorInfo.IME_ACTION_SEND -> label = "send"
            EditorInfo.IME_ACTION_NEXT -> label = "next"
            EditorInfo.IME_ACTION_DONE -> label = "done"
            else -> {
                label = "return"
                action = false
            }
        }
        if (multiLine) {
            keyboard.setEnterKey("return", false)
        } else {
            keyboard.setEnterKey(label, action)
        }

        updateAutoCap()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    private fun showEmoji(show: Boolean) {
        if (!::emoji.isInitialized) return
        if (show) {
            emoji.onShown()
            emoji.visibility = View.VISIBLE
            keyboard.visibility = View.INVISIBLE
        } else {
            emoji.visibility = View.GONE
            keyboard.visibility = View.VISIBLE
        }
    }

    private fun deleteOne() {
        val ic: InputConnection = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (selected != null && selected.isNotEmpty()) {
            ic.commitText("", 1)
        } else {
            // delete a whole emoji / surrogate pair correctly
            ic.deleteSurroundingTextInCodePoints(1, 0)
        }
    }

    /** Sets shift automatically at sentence starts when the app asks for capitals. */
    private fun updateAutoCap() {
        if (!::keyboard.isInitialized) return
        if (keyboard.shiftState == IosKeyboardView.SHIFT_LOCK) return
        if (!Prefs.autoCap(this)) {
            if (keyboard.shiftState == IosKeyboardView.SHIFT_ON) keyboard.setShift(IosKeyboardView.SHIFT_OFF)
            return
        }
        val info = currentInputEditorInfo ?: return
        if (info.inputType == InputType.TYPE_NULL) return
        val ic = currentInputConnection ?: return
        val caps = ic.getCursorCapsMode(info.inputType)
        keyboard.setShift(if (caps != 0) IosKeyboardView.SHIFT_ON else IosKeyboardView.SHIFT_OFF)
    }
}

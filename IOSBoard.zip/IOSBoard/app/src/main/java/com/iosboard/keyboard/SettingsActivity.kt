package com.iosboard.keyboard

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

/** Keyboard settings: theme, height, haptics, popup, sound, auto-capitalize, double-space period. */
class SettingsActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }

        col.addView(header("Keyboard Settings", 26f))

        // ---- theme
        col.addView(header("Theme", 16f))
        val group = RadioGroup(this)
        val names = listOf("Follow phone setting", "Light", "Dark")
        val current = Prefs.theme(this)
        names.forEachIndexed { i, n ->
            val rb = RadioButton(this).apply {
                text = n
                id = 1000 + i
                isChecked = i == current
            }
            group.addView(rb)
        }
        group.setOnCheckedChangeListener { _, checkedId -> Prefs.setInt(this, Prefs.THEME, checkedId - 1000) }
        col.addView(group)

        // ---- one-handed
        col.addView(header("One-handed mode", 16f))
        val handGroup = RadioGroup(this)
        val handNames = listOf("Off", "Left hand", "Right hand")
        val handCurrent = Prefs.oneHand(this)
        handNames.forEachIndexed { i, n ->
            handGroup.addView(RadioButton(this).apply {
                text = n
                id = 2000 + i
                isChecked = i == handCurrent
            })
        }
        handGroup.setOnCheckedChangeListener { _, checkedId -> Prefs.setInt(this, Prefs.ONEHAND, checkedId - 2000) }
        col.addView(handGroup)
        col.addView(TextView(this).apply { text = "Tip: press and hold the emoji key to switch quickly." })

        // ---- height
        col.addView(header("Keyboard height", 16f))
        val heightLabel = TextView(this)
        col.addView(heightLabel)
        val heightBar = SeekBar(this).apply {
            max = 50 // 80..130
            progress = Prefs.heightPercent(this@SettingsActivity) - 80
        }
        heightLabel.text = "${heightBar.progress + 80}%"
        heightBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                heightLabel.text = "${p + 80}%"
                Prefs.setInt(this@SettingsActivity, Prefs.HEIGHT, p + 80)
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        col.addView(heightBar)

        // ---- haptics
        col.addView(header("Feedback", 16f))
        col.addView(check("Vibrate on key press", Prefs.HAPTIC, Prefs.haptic(this)))
        val hapLabel = TextView(this)
        col.addView(hapLabel)
        val hapBar = SeekBar(this).apply {
            max = 35 // 5..40 ms
            progress = Prefs.hapticMs(this@SettingsActivity) - 5
        }
        hapLabel.text = "Vibration strength: ${hapBar.progress + 5} ms"
        hapBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                hapLabel.text = "Vibration strength: ${p + 5} ms"
                Prefs.setInt(this@SettingsActivity, Prefs.HAPTIC_MS, p + 5)
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        col.addView(hapBar)
        col.addView(check("Key click sound", Prefs.SOUND, Prefs.sound(this)))
        col.addView(check("Key-press popup", Prefs.POPUP, Prefs.popup(this)))

        // ---- typing
        col.addView(header("Typing", 16f))
        col.addView(check("Show word suggestions", Prefs.SUGGEST, Prefs.suggest(this)))
        col.addView(check("Smart punctuation (curly quotes, dashes, ...)", Prefs.SMART, Prefs.smart(this)))
        col.addView(check("Autocorrect common typos", Prefs.AUTOCORRECT, Prefs.autocorrect(this)))
        col.addView(check("Auto-capitalize sentences", Prefs.AUTOCAP, Prefs.autoCap(this)))
        col.addView(check("Double-space adds a period", Prefs.DOUBLE_SPACE, Prefs.doubleSpace(this)))

        // ---- test box
        col.addView(header("Test your changes", 16f))
        col.addView(EditText(this).apply {
            hint = "Tap here to preview the keyboard"
        })

        val scroll = ScrollView(this)
        scroll.addView(col)
        setContentView(scroll)
    }

    private fun header(s: String, size: Float) = TextView(this).apply {
        text = s
        textSize = size
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(18), 0, dp(6))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun check(label: String, key: String, value: Boolean) = CheckBox(this).apply {
        text = label
        isChecked = value
        setOnCheckedChangeListener { _, checked -> Prefs.setBool(this@SettingsActivity, key, checked) }
    }
}

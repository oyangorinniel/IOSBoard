package com.iosboard.keyboard

/** Characters shown when you press and hold a key. */
object Alternates {
    private fun split(s: String): List<String> = s.map { it.toString() }

    private val map: Map<String, List<String>> = mapOf(
        "a" to split("àáâäæãåā"),
        "e" to split("èéêëēėę"),
        "i" to split("îïíīįì"),
        "o" to split("ôöòóœøōõ"),
        "u" to split("ûüùúū"),
        "c" to split("çćč"),
        "n" to split("ñń"),
        "s" to split("ßśš"),
        "y" to split("ÿý"),
        "z" to split("žźż"),
        "l" to split("ł"),
        "d" to split("ð"),
        "-" to split("–—•"),
        "\"" to split("“”„«»"),
        "." to split("…"),
        "?" to split("¿"),
        "!" to split("¡"),
        "\$" to split("₱¢€£¥"),
        "0" to split("°"),
        "%" to split("‰"),
        "&" to split("§")
    )

    fun get(label: String): List<String> = map[label] ?: emptyList()
}

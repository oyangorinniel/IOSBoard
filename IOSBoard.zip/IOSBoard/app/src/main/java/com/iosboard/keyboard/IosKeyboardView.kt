package com.iosboard.keyboard

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.MotionEvent
import android.view.View

/** Draws and handles the iOS-style letter / number / symbol keyboard. */
@SuppressLint("ClickableViewAccessibility")
class IosKeyboardView(context: Context) : View(context) {

    interface Listener {
        fun onText(text: String)
        fun onDelete()
        fun onSpace()
        fun onEnter()
        fun onEmoji()
        fun onShiftChanged(state: Int)
        fun onSuggestion(word: String)
        fun onVoice()
    }

    companion object {
        const val SHIFT_OFF = 0
        const val SHIFT_ON = 1
        const val SHIFT_LOCK = 2

        private const val CHAR = 0
        private const val SHIFT = 1
        private const val DELETE = 2
        private const val TO_NUM = 3
        private const val TO_ABC = 4
        private const val TO_SYM = 5
        private const val SPACE = 6
        private const val ENTER = 7
        private const val EMOJI = 8
        private const val SPACER = 9
        private const val MIC = 10

        private const val PAGE_LETTERS = 0
        private const val PAGE_NUMBERS = 1
        private const val PAGE_SYMBOLS = 2
    }

    private class Key(val label: String, val type: Int, val weight: Float = 1f) {
        val rect = RectF()
        val hit = RectF()
    }

    var listener: Listener? = null

    var shiftState = SHIFT_OFF
        private set

    private var suggestions: List<String> = emptyList()
    private var sugPointer = -1
    private var sugSlot = -1

    fun setSuggestions(list: List<String>) {
        suggestions = list.take(3)
        invalidate()
    }

    private var page = PAGE_LETTERS
    private var enterLabel = "return"
    private var enterIsAction = false

    private var theme = KeyboardTheme.LIGHT
    private var rows: List<List<Key>> = emptyList()

    private val pressed = HashMap<Int, Key>()
    private var lastShiftTap = 0L

    private val handler = Handler(Looper.getMainLooper())
    private var repeating = false
    private val repeatRunnable = object : Runnable {
        override fun run() {
            repeating = true
            listener?.onDelete()
            buzz()
            handler.postDelayed(this, 55)
        }
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    private val vibrator: Vibrator? = findVibrator()

    @Suppress("DEPRECATION")
    private fun findVibrator(): Vibrator? {
        return if (Build.VERSION.SDK_INT >= 31) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private var keyH = dp(46f)
    private val hGap = dp(6f)
    private val vGap = dp(11f)
    private val sidePad = dp(3f)
    private var headroom = dp(50f)

    init {
        applyPrefs()
    }

    fun applyPrefs() {
        theme = KeyboardTheme.resolve(context)
        keyH = dp(46f) * Prefs.heightPercent(context) / 100f
        headroom = keyH * 1.1f
        buildRows()
        layoutKeys()
        requestLayout()
        invalidate()
    }

    fun setEnterKey(label: String, action: Boolean) {
        enterLabel = label
        enterIsAction = action
        invalidate()
    }

    fun setShift(state: Int) {
        if (shiftState != state) {
            shiftState = state
            invalidate()
        }
    }

    fun showLetters() {
        if (page != PAGE_LETTERS) {
            page = PAGE_LETTERS
            buildRows()
            layoutKeys()
            invalidate()
        }
    }

    // ------------------------------------------------------------------ layout

    private fun chars(s: String, weight: Float = 1f): List<Key> =
        s.map { Key(it.toString(), CHAR, weight) }

    private fun buildRows() {
        val bottom = listOf(
            Key(if (page == PAGE_LETTERS) "123" else "ABC", if (page == PAGE_LETTERS) TO_NUM else TO_ABC, 1.25f),
            Key("emoji", EMOJI, 1f),
            Key("mic", MIC, 1f),
            Key("space", SPACE, 4.25f),
            Key("return", ENTER, 2.5f)
        )
        rows = when (page) {
            PAGE_NUMBERS -> listOf(
                chars("1234567890"),
                chars("-/:;()₱&@\""),
                listOf(Key("#+=", TO_SYM, 1.5f)) + chars(".,?!'", 1.4f) + listOf(Key("del", DELETE, 1.5f)),
                bottom
            )
            PAGE_SYMBOLS -> listOf(
                chars("[]{}#%^*+="),
                chars("_\\|~<>\$€£•"),
                listOf(Key("123", TO_NUM, 1.5f)) + chars(".,?!'", 1.4f) + listOf(Key("del", DELETE, 1.5f)),
                bottom
            )
            else -> listOf(
                chars("qwertyuiop"),
                listOf(Key("", SPACER, 0.5f)) + chars("asdfghjkl") + listOf(Key("", SPACER, 0.5f)),
                listOf(Key("shift", SHIFT, 1.5f)) + chars("zxcvbnm") + listOf(Key("del", DELETE, 1.5f)),
                bottom
            )
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = (headroom + keyH * 4 + vGap * 4 + dp(6f)).toInt()
        setMeasuredDimension(w, h)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutKeys()
    }

    private fun layoutKeys() {
        val w = width.toFloat()
        if (w <= 0f) return
        val unit = (w - 2 * sidePad - 9 * hGap) / 10f
        var y = headroom + vGap / 2f
        for (row in rows) {
            var x = sidePad
            for (k in row) {
                val slot = k.weight * (unit + hGap)
                val keyW = slot - hGap
                if (k.type != SPACER) {
                    k.rect.set(x, y, x + keyW, y + keyH)
                    k.hit.set(x - hGap / 2f, y - vGap / 2f, x + keyW + hGap / 2f, y + keyH + vGap / 2f)
                }
                x += slot
            }
            // let the outermost keys catch touches at the screen edge
            val real = row.filter { it.type != SPACER }
            if (real.isNotEmpty()) {
                real.first().hit.left = 0f
                real.last().hit.right = w
            }
            y += keyH + vGap
        }
    }

    // ------------------------------------------------------------------ drawing

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(theme.background)
        drawSuggestions(canvas)
        for (row in rows) {
            for (k in row) {
                if (k.type == SPACER) continue
                drawKey(canvas, k, pressed.containsValue(k))
            }
        }
        for (k in pressed.values) {
            if (k.type == CHAR && Prefs.popup(context)) drawPopup(canvas, k)
        }
    }

    private fun drawSuggestions(canvas: Canvas) {
        if (suggestions.isEmpty()) return
        val stripH = headroom * 0.9f
        val slotW = width / 3f
        textPaint.color = theme.text
        textPaint.textSize = keyH * 0.42f
        val fm = textPaint.fontMetrics
        val baseline = stripH / 2f - (fm.ascent + fm.descent) / 2f
        for (i in suggestions.indices) {
            val cx = slotW * i + slotW / 2f
            var label = suggestions[i]
            val maxW = slotW - dp(12f)
            while (label.length > 1 && textPaint.measureText(label) > maxW) {
                label = label.dropLast(1)
            }
            canvas.drawText(label, cx, baseline, textPaint)
            if (i > 0) {
                fillPaint.color = theme.specialFill
                canvas.drawRect(slotW * i - dp(0.5f), stripH * 0.22f, slotW * i + dp(0.5f), stripH * 0.78f, fillPaint)
            }
        }
    }

    private fun isSpecial(k: Key) = when (k.type) {
        CHAR, SPACE -> false
        else -> true
    }

    private fun drawKey(canvas: Canvas, k: Key, down: Boolean) {
        val r = k.rect
        val radius = dp(5f)

        var fill = if (isSpecial(k)) theme.specialFill else theme.keyFill
        var textColor = theme.text

        if (k.type == ENTER && enterIsAction) {
            fill = theme.accent
            textColor = theme.accentText
        }
        if (k.type == SHIFT && shiftState != SHIFT_OFF) {
            fill = if (theme.isDark) 0xFFFFFFFF.toInt() else 0xFFFFFFFF.toInt()
            textColor = 0xFF000000.toInt()
        }
        if (down) {
            fill = if (isSpecial(k) && !(k.type == ENTER && enterIsAction)) theme.keyFill else theme.specialFill
        }

        shadowPaint.color = theme.keyShadow
        canvas.drawRoundRect(r.left, r.top + dp(1f), r.right, r.bottom + dp(1f), radius, radius, shadowPaint)
        fillPaint.color = fill
        canvas.drawRoundRect(r, radius, radius, fillPaint)

        when (k.type) {
            CHAR -> {
                if (down && Prefs.popup(context)) return
                textPaint.color = textColor
                textPaint.textSize = keyH * 0.52f
                val t = if (page == PAGE_LETTERS && shiftState != SHIFT_OFF) k.label.uppercase() else k.label
                drawCentered(canvas, t, r)
            }
            SHIFT -> drawShift(canvas, r, textColor)
            DELETE -> drawDelete(canvas, r, textColor)
            MIC -> drawMic(canvas, r, textColor)
            SPACE -> {
                textPaint.color = textColor
                textPaint.textSize = keyH * 0.33f
                drawCentered(canvas, "space", r)
            }
            ENTER -> {
                textPaint.color = textColor
                textPaint.textSize = keyH * 0.33f
                drawCentered(canvas, enterLabel, r)
            }
            EMOJI -> {
                textPaint.color = textColor
                textPaint.textSize = keyH * 0.5f
                drawCentered(canvas, "🙂", r)
            }
            else -> {
                textPaint.color = textColor
                textPaint.textSize = keyH * 0.33f
                drawCentered(canvas, k.label, r)
            }
        }
    }

    private fun drawCentered(canvas: Canvas, text: String, r: RectF) {
        val fm = textPaint.fontMetrics
        val baseline = r.centerY() - (fm.ascent + fm.descent) / 2f
        canvas.drawText(text, r.centerX(), baseline, textPaint)
    }

    private fun drawShift(canvas: Canvas, r: RectF, color: Int) {
        val cx = r.centerX()
        val cy = r.centerY()
        val s = keyH * 0.2f
        path.reset()
        path.moveTo(cx, cy - s)
        path.lineTo(cx + s * 1.1f, cy)
        path.lineTo(cx + s * 0.45f, cy)
        path.lineTo(cx + s * 0.45f, cy + s)
        path.lineTo(cx - s * 0.45f, cy + s)
        path.lineTo(cx - s * 0.45f, cy)
        path.lineTo(cx - s * 1.1f, cy)
        path.close()
        iconPaint.color = color
        iconPaint.style = if (shiftState == SHIFT_OFF) Paint.Style.STROKE else Paint.Style.FILL
        iconPaint.strokeWidth = dp(1.8f)
        iconPaint.strokeJoin = Paint.Join.ROUND
        canvas.drawPath(path, iconPaint)
        if (shiftState == SHIFT_LOCK) {
            iconPaint.style = Paint.Style.FILL
            canvas.drawRect(cx - s * 0.45f, cy + s * 1.25f, cx + s * 0.45f, cy + s * 1.55f, iconPaint)
        }
    }

    private fun drawMic(canvas: Canvas, r: RectF, color: Int) {
        val cx = r.centerX()
        val cy = r.centerY()
        val bw = keyH * 0.13f
        val bh = keyH * 0.24f
        iconPaint.color = color
        iconPaint.style = Paint.Style.FILL
        canvas.drawRoundRect(cx - bw, cy - bh - keyH * 0.04f, cx + bw, cy + bh * 0.3f, bw, bw, iconPaint)
        iconPaint.style = Paint.Style.STROKE
        iconPaint.strokeWidth = dp(1.8f)
        iconPaint.strokeCap = Paint.Cap.ROUND
        val ar = bw * 1.9f
        val arcRect = RectF(cx - ar, cy - ar * 0.9f, cx + ar, cy + ar * 1.1f)
        canvas.drawArc(arcRect, 0f, 180f, false, iconPaint)
        canvas.drawLine(cx, cy + ar * 1.1f, cx, cy + ar * 1.1f + keyH * 0.08f, iconPaint)
    }

    private fun drawDelete(canvas: Canvas, r: RectF, color: Int) {
        val cx = r.centerX()
        val cy = r.centerY()
        val w = keyH * 0.32f
        val h = keyH * 0.2f
        path.reset()
        path.moveTo(cx - w, cy)
        path.lineTo(cx - w * 0.45f, cy - h)
        path.lineTo(cx + w, cy - h)
        path.lineTo(cx + w, cy + h)
        path.lineTo(cx - w * 0.45f, cy + h)
        path.close()
        iconPaint.color = color
        iconPaint.style = Paint.Style.STROKE
        iconPaint.strokeWidth = dp(1.8f)
        iconPaint.strokeJoin = Paint.Join.ROUND
        iconPaint.strokeCap = Paint.Cap.ROUND
        canvas.drawPath(path, iconPaint)
        val xs = h * 0.55f
        val xc = cx + w * 0.3f
        canvas.drawLine(xc - xs, cy - xs, xc + xs, cy + xs, iconPaint)
        canvas.drawLine(xc - xs, cy + xs, xc + xs, cy - xs, iconPaint)
    }

    private fun drawPopup(canvas: Canvas, k: Key) {
        val r = k.rect
        val popW = r.width() * 1.45f
        val popH = keyH * 1.2f
        var left = r.centerX() - popW / 2f
        if (left < dp(2f)) left = dp(2f)
        if (left + popW > width - dp(2f)) left = width - dp(2f) - popW
        val top = r.top - popH + keyH * 0.25f
        val rad = dp(9f)

        shadowPaint.color = theme.keyShadow
        fillPaint.color = theme.keyFill

        // bubble
        canvas.drawRoundRect(left, top + dp(1f), left + popW, top + popH + dp(1f), rad, rad, shadowPaint)
        canvas.drawRoundRect(left, top, left + popW, top + popH, rad, rad, fillPaint)
        // neck joining bubble to the key
        canvas.drawRect(r.left, top + popH - rad, r.right, r.top + rad, fillPaint)
        canvas.drawRoundRect(r, dp(5f), dp(5f), fillPaint)

        val t = if (page == PAGE_LETTERS && shiftState != SHIFT_OFF) k.label.uppercase() else k.label
        textPaint.color = theme.text
        textPaint.textSize = keyH * 0.9f
        val fm = textPaint.fontMetrics
        val baseline = top + (popH - keyH * 0.2f) / 2f - (fm.ascent + fm.descent) / 2f
        canvas.drawText(t, left + popW / 2f, baseline, textPaint)
    }

    // ------------------------------------------------------------------ touch

    private fun findKey(x: Float, y: Float): Key? {
        val cx = x.coerceIn(1f, width - 1f)
        for (row in rows) {
            for (k in row) {
                if (k.type != SPACER && k.hit.contains(cx, y)) return k
            }
        }
        return null
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val id = e.getPointerId(i)
                val k = findKey(e.getX(i), e.getY(i))
                if (k != null) {
                    pressed[id] = k
                    onPressDown(k)
                } else if (e.getY(i) < headroom && suggestions.isNotEmpty()) {
                    sugPointer = id
                    sugSlot = (e.getX(i) / (width / 3f)).toInt().coerceIn(0, 2)
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val id = e.getPointerId(i)
                    val old = pressed[id] ?: continue
                    val nk = findKey(e.getX(i), e.getY(i))
                    if (nk != null && nk !== old && old.type != DELETE) {
                        pressed[id] = nk
                        onPressDown(nk, silent = true)
                    }
                }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                val id = e.getPointerId(i)
                if (id == sugPointer) {
                    val slot = (e.getX(i) / (width / 3f)).toInt().coerceIn(0, 2)
                    if (slot == sugSlot && e.getY(i) < headroom && slot < suggestions.size) {
                        buzz()
                        click()
                        listener?.onSuggestion(suggestions[slot])
                    }
                    sugPointer = -1
                }
                val k = pressed.remove(id)
                if (k != null) onRelease(k)
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                pressed.clear()
                sugPointer = -1
                handler.removeCallbacks(repeatRunnable)
                invalidate()
            }
        }
        return true
    }

    private fun onPressDown(k: Key, silent: Boolean = false) {
        if (!silent) {
            buzz()
            click()
        }
        if (k.type == DELETE) {
            repeating = false
            listener?.onDelete()
            handler.removeCallbacks(repeatRunnable)
            handler.postDelayed(repeatRunnable, 420)
        }
    }

    private fun onRelease(k: Key) {
        when (k.type) {
            CHAR -> {
                val upper = page == PAGE_LETTERS && shiftState != SHIFT_OFF
                listener?.onText(if (upper) k.label.uppercase() else k.label)
                if (shiftState == SHIFT_ON) {
                    shiftState = SHIFT_OFF
                    listener?.onShiftChanged(shiftState)
                }
            }
            SHIFT -> {
                val now = System.currentTimeMillis()
                shiftState = when {
                    shiftState == SHIFT_LOCK -> SHIFT_OFF
                    shiftState == SHIFT_ON && now - lastShiftTap < 350 -> SHIFT_LOCK
                    shiftState == SHIFT_ON -> SHIFT_OFF
                    else -> SHIFT_ON
                }
                lastShiftTap = now
                listener?.onShiftChanged(shiftState)
            }
            DELETE -> handler.removeCallbacks(repeatRunnable)
            TO_NUM -> switchPage(PAGE_NUMBERS)
            TO_ABC -> switchPage(PAGE_LETTERS)
            TO_SYM -> switchPage(PAGE_SYMBOLS)
            SPACE -> listener?.onSpace()
            ENTER -> listener?.onEnter()
            EMOJI -> listener?.onEmoji()
            MIC -> listener?.onVoice()
        }
    }

    private fun switchPage(p: Int) {
        page = p
        buildRows()
        layoutKeys()
        invalidate()
    }

    @Suppress("DEPRECATION")
    private fun buzz() {
        if (!Prefs.haptic(context)) return
        val v = vibrator ?: return
        val ms = Prefs.hapticMs(context).toLong()
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                v.vibrate(ms)
            }
        } catch (_: Exception) {
        }
    }

    private fun click() {
        if (Prefs.sound(context)) ClickSound.play()
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(repeatRunnable)
        super.onDetachedFromWindow()
    }
}

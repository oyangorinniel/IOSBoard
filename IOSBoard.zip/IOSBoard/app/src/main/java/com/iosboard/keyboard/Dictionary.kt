package com.iosboard.keyboard

import android.content.Context

/** Word suggestions: words you have typed before come first, then a built-in common-word list. */
object Dictionary {
    private var words: List<String>? = null

    private fun load(c: Context): List<String> {
        words?.let { return it }
        val text = try {
            c.resources.openRawResource(R.raw.words).bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            ""
        }
        val list = text.split(Regex("\\s+")).filter { it.isNotEmpty() }
        words = list
        return list
    }

    fun suggest(c: Context, prefix: String, max: Int): List<String> {
        val p = prefix.lowercase()
        val out = LinkedHashSet<String>()
        for (w in Prefs.learned(c)) {
            if (w.startsWith(p) && w != p) {
                out.add(w)
                if (out.size >= max) return out.toList()
            }
        }
        for (w in load(c)) {
            if (w.startsWith(p) && w != p) {
                out.add(w)
                if (out.size >= max) break
            }
        }
        return out.toList()
    }
}

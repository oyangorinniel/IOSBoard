package com.iosboard.keyboard

import android.content.Context
import kotlin.math.abs

/**
 * Word suggestions. Order of preference:
 * 1. words you usually type after the previous word,
 * 2. common word pairs built in,
 * 3. words you have typed before,
 * 4. a built-in common-word list,
 * 5. close matches for typos (for example "teh" gives "the").
 */
object Dictionary {
    private var words: List<String>? = null

    private val builtinNext: Map<String, List<String>> = mapOf(
        "i" to listOf("am", "have", "think", "will", "love", "want", "don't"),
        "i'm" to listOf("going", "not", "so", "sorry", "here", "just"),
        "i'll" to listOf("be", "call", "see", "send", "let"),
        "i've" to listOf("been", "got", "never", "just"),
        "you" to listOf("are", "can", "have", "know", "too", "guys"),
        "you're" to listOf("welcome", "so", "right", "the"),
        "are" to listOf("you", "we", "they", "there"),
        "is" to listOf("it", "the", "this", "that", "there"),
        "was" to listOf("a", "the", "it", "just"),
        "the" to listOf("best", "same", "first", "other", "only", "most"),
        "to" to listOf("be", "the", "do", "get", "see", "go"),
        "a" to listOf("lot", "little", "good", "few", "great", "bit"),
        "what" to listOf("is", "are", "do", "time", "about", "happened"),
        "how" to listOf("are", "is", "do", "about", "much", "many"),
        "thank" to listOf("you", "god"),
        "thanks" to listOf("for", "a", "so", "po"),
        "good" to listOf("morning", "night", "afternoon", "evening", "luck", "job"),
        "see" to listOf("you", "it", "the"),
        "let" to listOf("me", "us", "you", "them"),
        "it" to listOf("is", "was", "will", "would", "looks"),
        "do" to listOf("you", "not", "it", "that"),
        "can" to listOf("you", "i", "we", "not"),
        "will" to listOf("be", "you", "do", "see"),
        "please" to listOf("send", "let", "call", "help", "reply"),
        "happy" to listOf("birthday", "new", "to", "for"),
        "have" to listOf("a", "to", "you", "been", "fun"),
        "ok" to listOf("thanks", "lang", "na", "po"),
        "okay" to listOf("thanks", "lang", "na", "po"),
        "hello" to listOf("po", "there", "everyone", "sir", "ma'am"),
        "hi" to listOf("there", "po", "everyone", "guys"),
        "love" to listOf("you", "it", "this", "that"),
        "miss" to listOf("you", "u", "na"),
        "on" to listOf("the", "my", "your", "a", "my way"),
        "in" to listOf("the", "a", "my", "your"),
        "of" to listOf("the", "course", "my", "your"),
        "and" to listOf("i", "the", "then", "you"),
        "for" to listOf("the", "you", "a", "your", "me"),
        "with" to listOf("you", "the", "my", "a"),
        "this" to listOf("is", "one", "was", "time"),
        "that" to listOf("is", "was", "you", "the"),
        "we" to listOf("are", "can", "will", "have"),
        "they" to listOf("are", "were", "will", "have"),
        "he" to listOf("is", "was", "has", "will"),
        "she" to listOf("is", "was", "has", "will"),
        "my" to listOf("name", "friend", "love", "phone", "own"),
        "your" to listOf("welcome", "name", "phone", "message"),
        "where" to listOf("are", "is", "do", "did"),
        "when" to listOf("are", "is", "will", "did", "you"),
        "why" to listOf("are", "is", "do", "not", "did"),
        "if" to listOf("you", "i", "it", "not"),
        "so" to listOf("much", "good", "sorry", "i", "happy"),
        "very" to listOf("good", "much", "well", "nice", "happy"),
        "just" to listOf("wanted", "a", "got", "want", "now"),
        "no" to listOf("problem", "worries", "one", "need", "more"),
        "not" to listOf("sure", "yet", "now", "have", "going"),
        "sorry" to listOf("for", "about", "po", "i", "late"),
        "yes" to listOf("please", "of", "sir", "po", "i"),
        "wait" to listOf("for", "a", "lang", "po", "i"),
        "nice" to listOf("to", "one", "day", "meeting", "work"),
        "see" to listOf("you", "it", "the", "later"),
        "take" to listOf("care", "a", "the", "it"),
        "talk" to listOf("to", "later", "soon", "about"),
        "call" to listOf("me", "you", "back", "later"),
        "text" to listOf("me", "you", "back", "later"),
        "send" to listOf("me", "it", "the", "you"),
        "going" to listOf("to", "home", "out", "on"),
        "want" to listOf("to", "you", "a", "some"),
        "need" to listOf("to", "a", "your", "some", "help"),
        "got" to listOf("it", "a", "the", "you"),
        "get" to listOf("the", "a", "it", "back", "some"),
        "what's" to listOf("up", "your", "the", "going", "that"),
        "that's" to listOf("great", "good", "fine", "all", "right"),
        "it's" to listOf("ok", "fine", "a", "not", "time"),
        "don't" to listOf("know", "worry", "want", "have", "forget"),
        "can't" to listOf("wait", "go", "make", "find", "believe"),
        "salamat" to listOf("po", "sa", "ha", "din"),
        "kumusta" to listOf("ka", "na", "po", "kayo"),
        "ako" to listOf("ay", "po", "na", "ba"),
        "ikaw" to listOf("ba", "ay", "na", "po"),
        "opo" to listOf("sir", "ma'am", "salamat", "po")
    )

    private fun load(c: Context): List<String> {
        words?.let { return it }
        val text = try {
            c.resources.openRawResource(R.raw.words).bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            ""
        }
        val list = text.split(Regex("\\s+")).filter { it.isNotEmpty() }.distinct()
        words = list
        return list
    }

    /** Likely next words when no letters have been typed yet for the current word. */
    fun nextWords(c: Context, prev: String, max: Int): List<String> {
        val out = LinkedHashSet<String>()
        if (prev.isNotEmpty()) {
            for (w in Prefs.nextAfter(c, prev)) {
                out.add(w)
                if (out.size >= max) return out.toList()
            }
            val built = builtinNext[prev]
            if (built != null) {
                for (w in built) {
                    out.add(w)
                    if (out.size >= max) return out.toList()
                }
            }
        }
        return out.toList()
    }

    /** Completions of [prefix], best first, with typo fixes as a fallback. */
    fun suggest(c: Context, prefix: String, max: Int, prev: String = ""): List<String> {
        val p = prefix.lowercase()
        val out = LinkedHashSet<String>()

        fun add(w: String): Boolean {
            if (w != p && w.startsWith(p)) out.add(w)
            return out.size >= max
        }

        if (prev.isNotEmpty()) {
            for (w in Prefs.nextAfter(c, prev)) if (add(w)) return out.toList()
            val built = builtinNext[prev]
            if (built != null) for (w in built) if (add(w)) return out.toList()
        }
        for (w in Prefs.learned(c)) if (add(w)) return out.toList()
        val all = load(c)
        for (w in all) if (add(w)) return out.toList()

        if (p.length >= 3 && !all.contains(p)) fuzzy(c, p, max, all, out)
        return out.toList()
    }

    private fun fuzzy(c: Context, p: String, max: Int, all: List<String>, out: MutableSet<String>) {
        val limit = if (p.length <= 4) 1 else 2
        val found = ArrayList<Pair<Int, String>>()
        val pool = Prefs.learned(c) + all
        for (w in pool) {
            if (abs(w.length - p.length) > limit) continue
            val d = distance(p, w)
            if (d in 1..limit) found.add(Pair(d, w))
        }
        found.sortBy { it.first }
        for ((_, w) in found) {
            out.add(w)
            if (out.size >= max) return
        }
    }

    /** Edit distance where swapping two neighbouring letters counts as one change. */
    private fun distance(a: String, b: String): Int {
        val n = a.length
        val m = b.length
        val d = Array(n + 1) { IntArray(m + 1) }
        for (i in 0..n) d[i][0] = i
        for (j in 0..m) d[0][j] = j
        for (i in 1..n) {
            for (j in 1..m) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                var v = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
                if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) {
                    v = minOf(v, d[i - 2][j - 2] + 1)
                }
                d[i][j] = v
            }
        }
        return d[n][m]
    }
}

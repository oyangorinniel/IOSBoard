package com.iosboard.keyboard

import android.content.Context
import android.content.SharedPreferences

/** Simple wrapper around SharedPreferences used by the keyboard and the settings screen. */
object Prefs {
    private const val FILE = "ios_board_prefs"

    const val THEME = "theme"              // 0 = follow phone, 1 = light, 2 = dark
    const val HEIGHT = "height_percent"    // 80..130
    const val HAPTIC = "haptic"
    const val HAPTIC_MS = "haptic_ms"      // 5..40
    const val POPUP = "popup"
    const val SOUND = "sound"
    const val AUTOCAP = "autocap"
    const val DOUBLE_SPACE = "double_space"
    private const val RECENT = "recent_emoji"

    private fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getInt(c: Context, key: String, def: Int): Int = sp(c).getInt(key, def)
    fun setInt(c: Context, key: String, value: Int) = sp(c).edit().putInt(key, value).apply()

    fun getBool(c: Context, key: String, def: Boolean): Boolean = sp(c).getBoolean(key, def)
    fun setBool(c: Context, key: String, value: Boolean) = sp(c).edit().putBoolean(key, value).apply()

    fun theme(c: Context) = getInt(c, THEME, 0)
    fun heightPercent(c: Context) = getInt(c, HEIGHT, 100).coerceIn(80, 130)
    fun haptic(c: Context) = getBool(c, HAPTIC, true)
    fun hapticMs(c: Context) = getInt(c, HAPTIC_MS, 12).coerceIn(5, 40)
    fun popup(c: Context) = getBool(c, POPUP, true)
    fun sound(c: Context) = getBool(c, SOUND, false)
    fun autoCap(c: Context) = getBool(c, AUTOCAP, true)
    fun doubleSpace(c: Context) = getBool(c, DOUBLE_SPACE, true)

    fun recents(c: Context): List<String> {
        val s = sp(c).getString(RECENT, "") ?: ""
        return if (s.isEmpty()) emptyList() else s.split(" ").filter { it.isNotEmpty() }
    }

    fun addRecent(c: Context, emoji: String) {
        val list = recents(c).toMutableList()
        list.remove(emoji)
        list.add(0, emoji)
        while (list.size > 32) list.removeAt(list.size - 1)
        sp(c).edit().putString(RECENT, list.joinToString(" ")).apply()
    }
}

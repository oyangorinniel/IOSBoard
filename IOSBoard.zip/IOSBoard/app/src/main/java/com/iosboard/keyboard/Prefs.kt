package com.iosboard.keyboard

import android.content.Context
import android.content.SharedPreferences

/** Simple wrapper around SharedPreferences used by the keyboard and the settings screen. */
object Prefs {
    private const val FILE = "ios_board_prefs"

    const val THEME = "theme"              // 0 = follow phone, 1 = light, 2 = dark
    const val HEIGHT = "height_percent"    // 80..130
    const val HAPTIC = "haptic"
    const val HAPTIC_MS = "haptic_ms"      // 5..40
    const val POPUP = "popup"
    const val SOUND = "sound"
    const val AUTOCAP = "autocap"
    const val DOUBLE_SPACE = "double_space"
    const val SUGGEST = "suggest"
    const val ONEHAND = "one_hand"          // 0 = off, 1 = left, 2 = right
    const val SMART = "smart_punct"
    const val AUTOCORRECT = "autocorrect"
    private const val LEARNED = "learned_words"
    private const val RECENT = "recent_emoji"

    private fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getInt(c: Context, key: String, def: Int): Int = sp(c).getInt(key, def)
    fun setInt(c: Context, key: String, value: Int) = sp(c).edit().putInt(key, value).apply()

    fun getBool(c: Context, key: String, def: Boolean): Boolean = sp(c).getBoolean(key, def)
    fun setBool(c: Context, key: String, value: Boolean) = sp(c).edit().putBoolean(key, value).apply()

    fun theme(c: Context) = getInt(c, THEME, 0)
    fun heightPercent(c: Context) = getInt(c, HEIGHT, 100).coerceIn(80, 130)
    fun haptic(c: Context) = getBool(c, HAPTIC, true)
    fun hapticMs(c: Context) = getInt(c, HAPTIC_MS, 12).coerceIn(5, 40)
    fun popup(c: Context) = getBool(c, POPUP, true)
    fun sound(c: Context) = getBool(c, SOUND, true)
    fun suggest(c: Context) = getBool(c, SUGGEST, true)
    fun oneHand(c: Context) = getInt(c, ONEHAND, 0).coerceIn(0, 2)
    fun smart(c: Context) = getBool(c, SMART, true)
    fun autocorrect(c: Context) = getBool(c, AUTOCORRECT, true)

    private var learnedCache: MutableMap<String, Int>? = null

    private fun learnedMap(c: Context): MutableMap<String, Int> {
        learnedCache?.let { return it }
        val m = LinkedHashMap<String, Int>()
        val s = sp(c).getString(LEARNED, "") ?: ""
        for (line in s.split("\n")) {
            val p = line.split(" ")
            if (p.size == 2) p[1].toIntOrNull()?.let { m[p[0]] = it }
        }
        learnedCache = m
        return m
    }

    fun learned(c: Context): List<String> =
        learnedMap(c).entries.sortedByDescending { it.value }.map { it.key }

    fun learnWord(c: Context, word: String) {
        val m = learnedMap(c)
        m[word] = (m[word] ?: 0) + 1
        if (m.size > 3000) {
            val lowest = m.entries.minByOrNull { it.value }
            if (lowest != null) m.remove(lowest.key)
        }
        sp(c).edit().putString(LEARNED, m.entries.joinToString("\n") { "${it.key} ${it.value}" }).apply()
    }
    fun autoCap(c: Context) = getBool(c, AUTOCAP, true)
    fun doubleSpace(c: Context) = getBool(c, DOUBLE_SPACE, true)

    fun recents(c: Context): List<String> {
        val s = sp(c).getString(RECENT, "") ?: ""
        return if (s.isEmpty()) emptyList() else s.split(" ").filter { it.isNotEmpty() }
    }

    fun addRecent(c: Context, emoji: String) {
        val list = recents(c).toMutableList()
        list.remove(emoji)
        list.add(0, emoji)
        while (list.size > 32) list.removeAt(list.size - 1)
        sp(c).edit().putString(RECENT, list.joinToString(" ")).apply()
    }
}

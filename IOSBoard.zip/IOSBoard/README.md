# iOS Board

An iOS-style Android keyboard: light/dark (follows your phone), key-press popup, haptics,
shift / caps lock, auto-capitalize, emoji panel and a settings screen. It works in Messenger,
Viber and any other app, because it is a real Android keyboard.

Note: emoji use your phone's own emoji font. Apple's emoji artwork is copyrighted and not included.

## Get the APK with GitHub (no Android Studio)

1. Create a new repository on github.com.
2. Upload everything in this folder (including the hidden `.github` folder) to the repository's `main` branch.
3. Open the **Actions** tab, choose **Build APK**, and wait for the green check. (Run it manually with **Run workflow** if it did not start.)
4. Open the finished run and download **iOS-Board-debug-apk**, then unzip it.
5. Copy `app-debug.apk` to your phone and install it (allow "Install unknown apps" if asked).

## Turn it on

1. Open **iOS Board**, tap **Enable keyboard**, and switch on *iOS Board Keyboard*.
2. Tap **Choose keyboard** and select it.
3. Use **Keyboard settings** for theme, height, vibration strength, popup, sound and typing options.

## Build locally

Open the folder in Android Studio and press Run, or use `gradle :app:assembleDebug` with Gradle 8.7+ and JDK 17.
